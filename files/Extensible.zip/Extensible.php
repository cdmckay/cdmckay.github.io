<?php

class Extensible
{
    public function __call($name, $args)
    {
        return self::methodDispatcher($this, $name, $args);
    }

    private static $methodTable = array();

    public static function methodDispatcher($instance, $name, $args)
    {
        $class = get_class($instance);
        $table =& self::$methodTable;

        $table =& self::$methodTable;
        $class = get_class($instance);
        do
        {
            if (array_key_exists($class, $table) && array_key_exists($name, $table[$class]))
                break;

            $class = get_parent_class($class);
        }
        while ($class !== false);

        if ($class === false)
            throw new NException("Method not found");

        $func = $table[$class][$name];
        array_unshift($args, $instance);

        return call_user_func_array($func, $args);
    }

    public static function addMethod($methodName, $method)
    {
        $class = get_called_class();

        $table =& self::$methodTable;
        if (!array_key_exists($class, $table))
        {
            $table[$class] = array();
        }

        $table[$class][$methodName] = $method;
    }
}

final class Bug extends Extensible {
    private $name;
    private $arms;
    public function __construct($name, $arms) {
        $this->name = $name;
        $this->arms = $arms;
    }
    public function getName() { return $this->name; }
    public function getArms() { return $this->arms; }
}

Bug::addMethod("hug", function($bug, $otherBug) {
    echo $bug->getName() . " hugs " . $otherBug->getName();
});

Bug::addMethod("punch", function($bug, $otherBug) {
    echo $bug->getName()
       . " punches " . $otherBug->getName()
       . " with " . $bug->getArms() . " fists";
});

$doug = new Bug("Doug", 10);
$fred = new Bug("Fred", 4);
$fred->hug($doug);
$doug->punch($fred);

class Foo extends Extensible { }
class Bar extends Foo { }
class Baz extends Bar { }
Foo::addMethod("customMethod", function($object) {
    return "Foo";
});

$baz = new Baz();
$result = $baz->customMethod();
echo $result;