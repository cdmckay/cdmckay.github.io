(function($){

$(function(){

    $("#search").submit(function(event, info) {
        var text = $("input[id=search-text]", this);
        text.blur();

        var results = $("#search-results", this).empty();
        results.append($("<li>", {
            "class": "sep",
            text: 'Results for "' + text.val() + '"'
        }));

        $.get("search.php",
            { value: text.val() },
            function(data) {
                $.each(data, function(i, song) {
                    var str = song.artist 
                        + " - "
                        + song.title;
                    $("<li>")
                        .text(str)
                        .appendTo(results);
                });
            }
        );

        return false;       
    });

});

})(jQuery);
