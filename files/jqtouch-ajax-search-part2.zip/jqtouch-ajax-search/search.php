<?php

class Song {
    public $artist;
    public $title;

    public function __construct($artist, $title) {
        $this->artist = $artist;
        $this->title = $title;
    }
}

$songs = array(
    new Song("Weezer", "Say It Ain't So"),
    new Song("Weezer", "Undone"),
    new Song("Cake", "Meanwhile, Rick James..."),
    new Song("The Stars", "Ageless Beauty"),
    new Song("Roy Orbison", "In Dreams")
);

function search($songs, $value) {
    if (empty($value))
        return $songs;

    $matches = array();
    foreach ($songs as $s)
    {
        $matchArtist = stripos($s->artist, $value) !== false;
        $matchTitle = stripos($s->title, $value) !== false;
        if ($matchArtist || $matchTitle)
            $matches[] = $s;
    }
    return $matches;
}

$value = $_GET['value'];
$matches = search($songs, $value);

header('Content-Type: application/json');
echo json_encode($matches);